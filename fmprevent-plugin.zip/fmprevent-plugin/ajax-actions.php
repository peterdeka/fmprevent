<?php 

if(is_admin()){
	add_action( 'wp_ajax_add_order', 'my_action_callback' );
	add_action( 'wp_ajax_nopriv_add_order', 'my_action_callback' );
}


function my_action_callback(){
	$order=json_decode($_POST['order'], true);
	echo $order;
	die();
}

?>